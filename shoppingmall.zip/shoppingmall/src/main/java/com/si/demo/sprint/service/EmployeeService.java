package com.si.demo.sprint.service;

import java.util.List;

import com.si.demo.sprint.entity.Employee;



public interface EmployeeService {
	public Employee saveEmployee(Employee employee);

	public List<Employee> fetchEmployeeList();

	public Employee fetchEmployeeById(Long id);

	public void deleteEmployeeById(Long id);

	public Employee updateEmployee(Long id, Employee employee);


}
